clear all
close all
clc
path = ('C:\Users\Heidari\Desktop\TERM 6\RS\RS1 Physics\TA\data\');
Q = [];
for i=1:7
    if i==6
        continue
    end
    n = num2str(i);
    n = string(n);
    direct = path + "b" + n + ".dat";
    b = fopen(direct);
    A = fread(b,[2048 2048]);
    Q1 = struct('n',n,'A',A');
    Q = [Q,Q1];
    fclose(b);
    clear Q1 A
end
NDVI = imread('C:\Users\Heidari\Desktop\helya\NDVI.png');
% imwrite(NDVI_RGB,'D:\D\lesson\term 6\RS\NDVI.jpg')
NDVI=imresize(NDVI,[2048 2048]);
OIF = imread('C:\Users\Heidari\Desktop\helya\oif.png');
I = uint8(Q(5).A);
cloud = roipoly(NDVI);
water2= roipoly(NDVI);
jungle= roipoly(NDVI);
urban2= roipoly(NDVI);
soil22= roipoly(NDVI);
crop = roipoly(NDVI);
class_name =[string('water'),string('cloud'),string('forest'),string('soil'),string('urban'),string('crop')];
class_val = [water2,cloud,jungle,soil22,urban2,crop];
class = [];
for i=1:length(class_name) 
 b1 = Q(1).A(class_val(1:2048,2048*(i-1)+1:2048*i));
 b2 = Q(2).A(class_val(1:2048,2048*(i-1)+1:2048*i));
 b3 = Q(3).A(class_val(1:2048,2048*(i-1)+1:2048*i));
 b4 = Q(4).A(class_val(1:2048,2048*(i-1)+1:2048*i));
 b5 = Q(5).A(class_val(1:2048,2048*(i-1)+1:2048*i));
 b7 = Q(6).A(class_val(1:2048,2048*(i-1)+1:2048*i));
 B = [b1,b2,b3,b4,b5,b7];
 for j=1:length(Q) 
 M(j,1) = mean(B(:,j));
 sigma(j,1) = var(B(:,j));
 end
 
 cls_str = struct('class',class_name(i),'b1',b1,'b2',b2,'b3',b3,'b4',b4,'b5',b5,'b7',b7,'M',M,'var',sigma);
 class = [class;cls_str];
 clear cls_str
end

var_final = [];
var_sum = 0;
for i=1:6
    for j=1:6
        var_sum = var_sum + class(j).var(i);
    end
    var_final = [var_final;var_sum];
    var_sum = 0;
end

var_final = (var_final)/6;


M = zeros(1,2048);
dist =[];
for i=1:length(class)
    for j=1:length(Q)
        M(:,:) = class(i).M(j);
        for k=1:2048
            D(k,:) = ((Q(j).A(k,:) - M).^2)/var_final(j);
    
        end
            d_str = struct('class',class_name(i),'band',j,'dis',D);
            dist = [dist;d_str];
            clear d_str
            D = [];

    end
end


total_d = [];
for i=1:length(dist)/6
    
    sum_dist =(dist(6*i-5).dis + dist(6*i-4).dis + dist(6*i-3).dis + dist(6*i-2).dis + dist(6*i-1).dis + dist(6*i).dis);
    sum_d =  sqrt(sum_dist);
    str = struct('class',class_name(i),'total',sum_d);
    total_d = [total_d;str];
    clear str
    
end


final = zeros(2048);
for i=1:2048
    compare = [total_d(1).total(i,:);total_d(2).total(i,:);total_d(3).total(i,:);total_d(4).total(i,:);total_d(5).total(i,:);total_d(6).total(i,:)];
    min_c = (min(compare));
   [row,col] = find(compare==min_c);

    final(i,:) = row;
end


final = final';
zero = zeros(2048,2048,'uint8');
water_cond = (final==1)';
cloud_cond = (final==2)';
veg_cond = (final==3)';
soil_cond = (final==4)';
urban_cond = (final==5)';
agri_cond = (final==6)';

S = uint8(cat(3,127*soil_cond,127*soil_cond,zero));
G = uint8(cat(3,zero,200*veg_cond,zero));
B = uint8(cat(3,zero,zero,150*water_cond));
C = uint8(cat(3,250*cloud_cond,250*cloud_cond,250*cloud_cond));
U = uint8(cat(3,200*urban_cond,50*urban_cond,zero));
A = uint8(cat(3,zero,150*agri_cond,50*agri_cond));

colored = S+G+B+U+A+C;
figure
imshow(colored);
title('mahalanobis')
colormap([1 0 0; 0 1 0;0 0 1;1 1 1;0.5 0.5 0;0 0.75 0.25]);
colorbar('Ticks', [0.166,0.33,0.5,0.67,0.833,1],...
        'TickLabels',{'dense veg','crop','land','water','urban','soil'});


area = [];
for i=1:length(class)
    ind = find(final==i);
    area_str = struct('class',class_name(i),'area',length(ind)*900);            %landsat image 30*30
    area = [area,area_str];
    clear area_str 
end

%test
    OIF=imresize(OIF,[2048 2048]);
    figure
    water_t = roipoly(OIF); 
    cloud_t = roipoly(OIF);
    forest_t = roipoly(OIF);
    soil_t = roipoly(OIF);
    urban_t = roipoly(OIF);
    crop_t = roipoly(OIF);
    
class_val = [water_t,cloud_t,forest_t,soil_t,urban_t,crop_t];

test = [];
for i=1:6
    class = class_val(1:2048,2048*(i-1)+1:2048*i);
    test_str = struct('class_name',class_name(i),'class',class);
    test = [test;test_str];
end

[OA,kappa,confusion_matrix] = accuracy(test,final);