%%Mojgan Heidari-810397112
%% address pixel samte chap bala
%%item 1
path=('C:\Users\Heidari\Desktop\TERM 6\RS\RS1 Physics\TA\data\');
list_dat = dir(strcat(path,'*.dat'));

start = 860;
bands = [];
for i=1:7
    n = num2str(i);
    n = string(n);
    stri = string('C:\Users\Heidari\Desktop\TERM 6\RS\RS1 Physics\TA\data\') + string(list_dat(i).name);
    b = fopen(stri);
    A = fread(b,[2048 2048]);
    A = A';
    final = start + 1023;
    sub_img = A(start:final,start:final);

    
%     save as image(jpg or png)
    name = string('C:\Users\Heidari\Desktop\TERM 6\RS\RS1 Physics\TA\data2\')+ "Subband" + n + ".jpg";
    imwrite(uint8(sub_img), name)
    
%     save as mat 
    name2 = string('C:\Users\Heidari\Desktop\TERM 6\RS\RS1 Physics\TA\data2\')+ "Subband" + n + ".mat";
    save(name2, "sub_img")
    
%     save as dat
    name3 = string('C:\Users\Heidari\Desktop\TERM 6\RS\RS1 Physics\TA\data2\')+ "Subband" + n + ".dat";
    dlmwrite(name2, A)
    
    band = struct('n',n,'A',A,'subset',sub_img);
    bands = [bands,band];
    fclose(b);
end

clear A band

for i=1:7
    n = num2str(i);
    n = string(n);
    address = "C:\Users\Heidari\Desktop\TERM 6\RS\RS1 Physics\TA\" + "Subband" + n + ".dat";
    fid = fopen(address,'w');
    fwrite(fid,bands(i).subset);
    fclose(fid)
end


%%read saved dat file

bands2 = [];
for i=1:7
    n = num2str(i);
    n = string(n);
    stri = 'C:\Users\Heidari\Desktop\TERM 6\RS\RS1 Physics\TA\data2\' + "Subband" + n + ".dat";
    b = fopen(stri);
    A2 = fread(b,[1024 1024]);
    band2 = struct('n',n,"image",A2);
    bands2 = [bands2,band2];
end
clear band2 A2 
%%end of item 1
%%item 2
band_num = input ('select the number of band :')
while band_num<8
   
if band_num==7
 A2 = bands2(7).image;
 % show band 7 
 figure(3)
 imshow(mat2gray(A2))
 title("band7")
 
  elseif band_num==6
   A3=bands2(6).image;
   % show band 6 
   figure(4)
   imshow(mat2gray(A3))
   title("band6")
   
 elseif band_num==5
  A4=bands2(5).image;
  % show band 5 
  figure(5)
  imshow(mat2gray(A4))
  title("band5")
 
 elseif band_num==4
  A5=bands2(4).image;
  % show band 4 
  figure(6)
  imshow(mat2gray(A5))
  title("band4")

  elseif band_num==3
  A6=bands2(3).image;
  % show band 3 
  figure(7)
  imshow(mat2gray(A6))
  title("band3")

 elseif band_num==2
  A7=bands2(2).image;
  % show band 2 
  figure(8)
  imshow(mat2gray(A7))
  title("band2")

 elseif band_num==1
  A8=bands2(1).image;
  % show band 1 
  figure(9)
  imshow(mat2gray(A8))
  title("band1")

end
band_num = input ('select the number of band :');
if band_num>7
  disp('It is not in range!')
break  
end
end
%%end of item 2
%%item 3
image1=imread('C:\Users\Heidari\Desktop\TERM 6\RS\RS1 Physics\TA\data2\Subband1.jpg');
image2=imread('C:\Users\Heidari\Desktop\TERM 6\RS\RS1 Physics\TA\data2\Subband2.jpg');
image3=imread('C:\Users\Heidari\Desktop\TERM 6\RS\RS1 Physics\TA\data2\Subband3.jpg');
image4=imread('C:\Users\Heidari\Desktop\TERM 6\RS\RS1 Physics\TA\data2\Subband4.jpg');
image5=imread('C:\Users\Heidari\Desktop\TERM 6\RS\RS1 Physics\TA\data2\Subband5.jpg');
image6=imread('C:\Users\Heidari\Desktop\TERM 6\RS\RS1 Physics\TA\data2\Subband6.jpg');
image7=imread('C:\Users\Heidari\Desktop\TERM 6\RS\RS1 Physics\TA\data2\Subband7.jpg');

DN1=image1;
DN2=image2;
DN3=image3;
DN4=image4;
DN5=image5;
DN6=image6;
DN7=image7;

r1=im2double(image1);
r2=im2double(image2);
r3=im2double(image3);
r4=im2double(image4);
r5=im2double(image5);
r7=im2double(image7);

LRmin=-1.17;
LRmax=264.0;
LNIRmin=-1.51;
LNIRmax=221.0;
LTIRmin=1.2378;
LTIRmax=15.303;

LR =((LRmax-LRmin)/255).*DN3+LRmin;
LNIR =((LNIRmax-LNIRmin)/255).*DN4+LNIRmin;
LTIR=((LTIRmax-LTIRmin)/255).*DN5+LTIRmin;

DN3=image3;
DN4=image4;
GNIR=(LNIRmax-LNIRmin)/255;     
GR=(LRmax-LRmin)/255;            
DN44 = double(DN4);       
DN33 = double(DN3);
LNIR = (GNIR*DN44)+LNIRmin;
LR = (GR*DN33)+LRmin;


f = input ('Enter a number[ 1)LR/LNIR  2)NDVI  3)SAVI 4)MSAVI 5)MSAVI2 6)OIF ]:')
while f<7
   
if f==1

band_num = input('Enter the number of band(3 or 4):');
while band_num==3 | band_num==4
    %%BAND 3
if band_num==3
   LR =((LRmax-LRmin)/255).*DN3+LRmin
   figure(12)
   imshow(LR)
   title("LR")
%%BAND 4
elseif band_num==4
   LNIR =((LNIRmax-LNIRmin)/255).*DN4+LNIRmin
   figure(13)
   imshow(LNIR)
   title("LNIR")
end
if band_num ~=3 | band_num ~=4
  disp('It is not in range!')
break  
end


end

%%end of item 3
elseif f==2
%%item 4
LR=im2double(LR);
LNIR=im2double(LNIR);
NDVI1 = @(LR1,LNIR1)(LNIR1-LR1)./(LNIR1+LR1);
NDVI=NDVI1(LR,LNIR);
NDVI_RGB = zeros(2048,2048,3,'uint8');
zero = zeros(1024,1024,'uint8');
in=input('Enter x(NDVI):')
jn=input('Enter y(NDVI):')
if 0<in<1024 
    if 0<jn<1024
sNDVI=NDVI(in,jn)
    end
else
   disp('It is not in range!') 
end
figure(22)
  imshow(mat2gray(NDVI))
  title("NDVI")
%%item 5
LTIRmin=1.2378;
LTIRmax=15.303;

LR =((LRmax-LRmin)/255).*DN3+LRmin;
LNIR =((LNIRmax-LNIRmin)/255).*DN4+LNIRmin;
LTIR=((LTIRmax-LTIRmin)/255).*DN5+LTIRmin;
Dense_vegetation = (NDVI>=0.5 & NDVI<=1);
Medium_vegetation = (NDVI>=0.140 & NDVI<0.5);
Sparse_vegetation = (NDVI>=0.09 & NDVI<0.140);
Bareground = (NDVI>=0.025 & NDVI<0.09);
Cloud = (NDVI>=0.002 & NDVI<0.025);
Ice_and_snow = (NDVI>=-0.046 & NDVI<0.002);
Water = (NDVI>=-1 & NDVI<-0.046);
%%item 10
for i=1:1024
    for j=1:1024
         if (NDVI(i,j)>=0.5)
           sigma_Dense_vegetation(i,j)=0.99;
         end
         if NDVI(i,j)>=0.2 
             if NDVI(i,j)<0.5
           sigma_Medium_vegetation(i,j)=0.004*((NDVI(i,j)-0.2)/(0.3)).^2+0.986;
             end
         end
         if NDVI(i,j)<0.2
             if NDVI(i,j)>=0
           sigma_Sparse_vegetation(i,j)=0.97;
             end
         end
        if (NDVI(i,j)<0)
           sigma_Water(i,j)=1;
         end 
         
    end
end
sigma=sigma_Dense_vegetation+sigma_Medium_vegetation+sigma_Sparse_vegetation+sigma_Water;
for i=1:1024
    for j=1:1024
T(i,j)=(1260.56./(log((607.76*sigma(i,j)./im2double(LTIR(i,j)))+1)));

    end
end
T1=uint8(T);
sigma1=uint8(sigma);
figure(24)
imshow(mat2gray(sigma));
title('Thermal')
%%end of item 10

imwrite(NDVI_RGB,'NDVI.png')
NDVI_RGB_Dense_vegetation = uint8(cat(3,zero,50*Dense_vegetation,zero));
NDVI_RGB_Medium_vegetation = uint8(cat(3,zero,150*Medium_vegetation,zero));
NDVI_RGB_Sparse_vegetation = uint8(cat(3,zero,250*Sparse_vegetation,zero));
NDVI_RGB_Bareground = uint8(cat(3,255*Bareground,255*Bareground,zero));
NDVI_RGB_Cloud = uint8(cat(3,255*Cloud,255*Cloud,255*Cloud));
NDVI_RGB_Ice_and_snow = uint8(cat(3,127*Ice_and_snow,127*Ice_and_snow,127*Ice_and_snow));
NDVI_RGB_Water = uint8(cat(3,zero,zero,150*Water));
NDVI_RGB = NDVI_RGB_Dense_vegetation + NDVI_RGB_Medium_vegetation + NDVI_RGB_Sparse_vegetation + NDVI_RGB_Bareground + NDVI_RGB_Cloud + NDVI_RGB_Ice_and_snow + NDVI_RGB_Water;


    

       
     if NDVI_RGB<0.2
    sigma_Sparse_vegetation=0.97
     end
if NDVI_RGB<0
    sigma_Bareground=1
     
end

figure(17)
imshow(NDVI_RGB);
title('NDVI RGB')
colormap([0 0.2 0;0 0.6 0;0 1 0;0 0 1;1 1 0;1 1 1])
colorbar('Ticks',[0.166,0.335,0.5,0.665,0.833,1],...
          'TickLabels',{'dense veg','medium veg','sparse veg','water','bare ground','cloud'})

imwrite(NDVI_RGB,'NDVI.png')

%%item 10
for i=1:1024
 for j=1:1024
 if (NDVI(i,j)>=0.5)
 sigma_Dense_vegetation(i,j)=0.99; end
 if NDVI(i,j)>=0.2 
 if NDVI(i,j)<0.5
 sigma_Medium_vegetation(i,j)=0.004*((NDVI(i,j)-0.2)/(0.3)).^2+0.986;
 end
 end
 if NDVI(i,j)<0.2
 if NDVI(i,j)>=0
 sigma_Sparse_vegetation(i,j)=0.97;
 end
 end
 if (NDVI(i,j)<0)
 sigma_Water(i,j)=1;
 end
 
 end
end
sigma=sigma_Dense_vegetation+sigma_Medium_vegetation+sigma_Sparse_veget
ation+sigma_Water;
for i=1:1024
 for j=1:1024
T(i,j)=(1260.56./(log((607.76*sigma(i,j)./im2double(LTIR(i,j)))+1)));
 end
end
T1=uint8(T);
sigma1=uint8(sigma);
figure(24)
imshow(mat2gray(sigma));
title('Thermal')
%%end of item 10

%%end of item 12

LRmin=-1.17;
LRmax=264.0;
LNIRmin=-1.51;
LNIRmax=221.0;
DN3=image3;
DN4=image4;
GNIR = (LNIRmax-LNIRmin)/255;     
GR = (LRmax-LRmin)/255;          
      
DN44 = double(DN4);       
DN33 = double(DN3);

LNIR = (GNIR*DN44)+LNIRmin;
LR = (GR*DN33)+LRmin;
elseif f==3
%%item 6
L=0.5;
SAVI=((LNIR-LR).*(1+L))./(LNIR+LR+L);
if SAVI<-1
 SAVI = -1;
elseif SAVI>1
 SAVI=1;
end
figure(18)
imshow(mat2gray(SAVI))
title('SAVI')

is=input('Enter x(SAVI):')
js=input('Enter y(SAVI):')

if 0<is<1024 
    if 0<js<1024
sSAVI=SAVI(is,js)
    end
else
   disp('It is not in range!') 
end
%%end of item 6

elseif f==4
%%item 7

S=1.17;
L=(2*S*(LNIR-LR).*(LNIR-S*LR))./(LNIR+LR);
MSAVI=((LNIR-LR).*(1+L))./(LNIR+LR+L);

l1=1-2*S*((LNIR-LR).*(LNIR-S*LR)./((LNIR+LR)));
msavi=(LNIR-LR.*(1+l1))./((LNIR+LR)+l1);


figure(19)
imshow(mat2gray(MSAVI));
title('MSAVI')

figure(23)
imshow(mat2gray(msavi));
title('msavi')

iMS=input('Enter x(MSAVI):');
jMS=input('Enter y(MSAVI):');
if 0<iMS<1024 
    if 0<jMS<1024
sMSAVI=MSAVI(iMS,jMS);
    end
else
   disp('It is not in range!') 
end


%%end of item 7

elseif f==5
%%item 8
MSAVI2 = ((2.*LNIR+1-sqrt((2.*LNIR+1).^2 - 8.*(LNIR - LR)))./2);

if MSAVI2<-1
 MSAVI2 = -1;
elseif MSAVI2>1
 MSAVI2=1;
end
figure(20)
imshow(mat2gray(MSAVI2))
title('MSAVI2')

iMS2=input('Enter x(MSAVI2):');
jMS2=input('Enter y(MSAVI2):');

if 0<iMS<1024 
    if 0<jMS<1024
sMSAVI2=MSAVI2(iMS2,jMS2);
    end
else
   disp('It is not in range!') 
end
%%end of item 8

elseif f==6
%%item 9
OIF1=@(s,d,f)(sum(std(s)+std(d)+std(f)))./(sum(corr(s,d)+corr(s,f)+corr(d,f)));
OIF123=OIF1(r1,r2,r3);
OIF124=OIF1(r1,r2,r4);
OIF125=OIF1(r1,r2,r5);
OIF127=OIF1(r1,r2,r7);
OIF134=OIF1(r1,r3,r4);
OIF135=OIF1(r1,r3,r5);
OIF137=OIF1(r1,r3,r7);
OIF145=OIF1(r1,r4,r5);
OIF147=OIF1(r1,r4,r7);
OIF157=OIF1(r1,r5,r7);
OIF234=OIF1(r2,r3,r4);
OIF235=OIF1(r2,r3,r5);
OIF237=OIF1(r2,r3,r7);
OIF245=OIF1(r2,r4,r5);
OIF247=OIF1(r2,r4,r7);
OIF257=OIF1(r2,r5,r7);
OIF347=OIF1(r3,r4,r7);
OIF357=OIF1(r3,r5,r7);
OIF457=OIF1(r4,r5,r7);
OIF345=OIF1(r3,r4,r5);
OIF=[OIF123;OIF124;OIF125;OIF127;OIF134;OIF135;OIF137;OIF145;OIF147;OIF
157;OIF234;OIF235;OIF237;OIF245;OIF247;OIF257;OIF347;OIF357;OIF457;OIF3
45];
OIFmax=max(OIF);
P=[1 2 3 OIF123;1 2 4 OIF124;1 2 5 OIF125;1 2 7 OIF127;1 3 4 OIF134;1 3 5 OIF135;1 3 7 OIF137;1 4 5 OIF145;1 4 7 OIF147;1 5 7 OIF157;2 3 4 OIF234;2 3 5 OIF235;2 3 7 OIF237;2 4 5 OIF245;2 4 7 OIF247;2 5 7 OIF257;3 4 7 OIF347;3 5 7 OIF357;4 5 7 OIF457;3 4 5 OIF345];
[~,i]=max(P(:,4))
disp(P(i,:))
B = eval(['image' num2str(P(i,1))]);
G = eval(['image' num2str(P(i,2))]);
R = eval(['image' num2str(P(i,3))]);
RGB_oifmax=uint8(cat ( 3 ,R,G,B));
figure(14)
imshow(RGB_oifmax)
title('RGB_OIFMAX')
%%RGB
b=imread('C:\Users\Heidari\Desktop\TERM 6\RS\RS1 Physics\TA\data2\Subband2.jpg');
g=imread('C:\Users\Heidari\Desktop\TERM 6\RS\RS1 Physics\TA\data2\Subband3.jpg');
r=imread('C:\Users\Heidari\Desktop\TERM 6\RS\RS1 Physics\TA\data2\Subband4.jpg');
RGB=uint8(cat(3,r,g,b));
figure(15)
imshow(RGB)
title('RGB')
%%end of item 9
end
f = input ('Enter a number[ 1)LR/LNIR  2)NDVI  3)SAVI 4)MSAVI 5)MSAVI2 6)OIF ]:')
if f>6
  disp('It is not in range!')
break  
end

end



