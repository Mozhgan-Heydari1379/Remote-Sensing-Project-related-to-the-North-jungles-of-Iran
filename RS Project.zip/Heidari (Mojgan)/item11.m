clear all
close all
clc

%% project 11

path = ('C:\Users\Heidari\Desktop\TERM 6\RS\RS1 Physics\TA\data\');
Q = [];
for i=1:7
    if i==6
        continue
    end
    n = num2str(i);
    n = string(n);
    direct = path + "b" + n + ".dat";
    b = fopen(direct);
    A = fread(b,[2048 2048]);
    Q1 = struct('n',n,'A',A');
    Q = [Q,Q1];
    fclose(b);
    clear Q1 A
end

NDVI_RGB = imread('C:\Users\Heidari\Desktop\helya\NDVI.png');
NDVI_RGB=imresize(NDVI_RGB,[2048 2048]);
% OIF = imread('OIF.png');
%I = uint8(Q(5).A);
%cloud = roipoly(I);
%forest = roipoly(I);
%soil = roipoly(I);
%urban = roipoly(I);
%water = roipoly(I);
%save('data.mat','water', 'cloud', 'forest', 'soil','urban', 'crop')

% data = load('data.mat');
% water = data.water;
% cloud = data.cloud;
% forest = data.forest;
% soil = data.soil;
% urban = data.urban;
% crop = data.crop;
% save('data.mat','water', 'cloud', 'forest', 'soil','urban', 'crop','shadow')

crop=roipoly(NDVI_RGB);
soil=roipoly(NDVI_RGB);
urban=roipoly(NDVI_RGB);
jungle=roipoly(NDVI_RGB);
cloud=roipoly(NDVI_RGB);
water=roipoly(NDVI_RGB);


class_name = [string('water'),string('cloud'),string('forest'),string('soil'),string('urban'),string('crop')];
class_val = [water,cloud,jungle,soil,urban,crop];
class = [];
a = [5,2,5.5,2,2,4];             %sigma cofactor

for i=1:length(class_name)   
    b1 = Q(1).A(class_val(1:2048,2048*(i-1)+1:2048*i));
    b2 = Q(2).A(class_val(1:2048,2048*(i-1)+1:2048*i));
    b3 = Q(3).A(class_val(1:2048,2048*(i-1)+1:2048*i));
    b4 = Q(4).A(class_val(1:2048,2048*(i-1)+1:2048*i));
    b5 = Q(5).A(class_val(1:2048,2048*(i-1)+1:2048*i));
    b7 = Q(6).A(class_val(1:2048,2048*(i-1)+1:2048*i));
    B = [b1,b2,b3,b4,b5,b7];
    for j=1:length(Q)       
        M(j,1) = mean(B(:,j));
        sigma(j,1) = std(B(:,j));
        L(j,1) = M(j,1)-a(i)*sigma(j,1);
        H(j,1) = M(j,1)+a(i)*sigma(j,1);
    end
    
    cls_str = struct('class',class_name(i),'b1',b1,'b2',b2,'b3',b3,'b4',b4,'b5',b5,'b7',b7,'M',M,'std',sigma,'L',L,'H',H);
    class = [class;cls_str];
    clear cls_str
end

for i=2:length(class)
    for j=1:length(class(i).H)
        if class(i-1).H(j)~=class(i).H(j)
            disp('PE is correct')
        else 
            disp('mixed pixel is possible')
        end
    end
end


cls_cond = zeros(length(Q(1).A));
cls_final = zeros(length(Q(1).A));
clsifid = [];

for i=1:length(class)
    for j=1:length(Q)
        h(j,1) = class(i).H(j);
        l(j,1) = class(i).L(j);       
        cls_cond = [Q(j).A>=l(j,1) & Q(j).A<= h(j,1)];
        v = find(Q(j).A>=l(j,1) & Q(j).A<= h(j,1));
        cls_final(v) = i;

        cls_str = struct('class',class_name(i),'band',j,'cls',cls_cond);
        clsifid = [clsifid;cls_str];
        clear cls_str cls_cond
    end
    
end


final = zeros(2048);
cond_2 = [];
for i=1:length(clsifid)/length(class_name)
        cls_test = clsifid(6*i-5).cls + clsifid(6*i-4).cls + clsifid(6*i-3).cls + clsifid(6*i-2).cls + clsifid(6*i-1).cls + clsifid(6*i).cls;
        ind = find(cls_test==6);
        final(ind) = i;
        
        str = struct('class',class_name(i),'cond',cls_test);
        cond_2 = [cond_2;str];
        clear str 
        cls_test = [];    
end
 
final = final';

%%RGB

zero = zeros(2048,2048,'uint8');
water_cond = (final==1)';
cloud_cond = (final==2)';
veg_cond = (final==3)';
soil_cond = (final==4)';
urban_cond = (final==5)';
agri_cond = (final==6)';

S = uint8(cat(3,127*soil_cond,127*soil_cond,zero));
G = uint8(cat(3,zero,200*veg_cond,zero));
B = uint8(cat(3,zero,zero,150*water_cond));
C = uint8(cat(3,250*cloud_cond,250*cloud_cond,250*cloud_cond));
U = uint8(cat(3,200*urban_cond,50*urban_cond,zero));
A = uint8(cat(3,zero,150*agri_cond,50*agri_cond));

colored = S+G+B+U+A+C;

figure
imshow(colored);
title('parallelepiped')
colormap([1 0 0; 0 1 0;0 0 1;1 1 1;0.6 0.6 0;0 0.75 0.25]);
colorbar('Ticks', [0.166,0.335,0.5,0.665,0.833,1],...
        'TickLabels',{'urban','forest','water','cloud','soil','crop'});


area = [];
for i=1:length(class)
    ind = find(final==i);
    ratio(i,1) = length(ind)/(length(Q(1).A)^2);
    
    area_str = struct('class',class_name(i),'area',length(ind)*900);            %landsat image 30*30
    area = [area,area_str];
    clear area_str 
end



%test
    OIF=imresize(OIF,[2048 2048]);
    figure
    water_t = roipoly(OIF); 
    cloud_t = roipoly(OIF);
    forest_t = roipoly(OIF);
    soil_t = roipoly(OIF);
    urban_t = roipoly(OIF);
    crop_t = roipoly(OIF);
    %save('test.mat','water_t', 'cloud_t', 'forest_t', 'soil_t','urban_t', 'crop_t')

class_val = [water_t,cloud_t,forest_t,soil_t,urban_t,crop_t];

test = [];
for i=1:6
    class = class_val(1:2048,2048*(i-1)+1:2048*i);
    test_str = struct('class_name',class_name(i),'class',class);
    test = [test;test_str];
end

[OA,kappa,confusion_matrix] = accuracy(test,final);

function ROI_selection 
       myimage = imread('NDVI-RGB.png');
       roiwindow = CROIEditor(myimage);

       addlistener(roiwindow,'MaskDefined',@your_roi_defined_callback)

       function your_roi_defined_callback(h,e)
            [mask, labels, n] = roiwindow.getROIData;
            delete(roiwindow); 
       end
end